<html>
<head>
<title>Lecture d'un sujet</title>
</head>
<body>

<?php
if (!isset($_GET['id_sujet_a_lire'])) {
	echo 'Sujet non d�fini.';
}
else {
?>
	<table width="500" border="1"><tr>
	<td>
	Auteur
	</td><td>
	Messages
	</td></tr>
	<?php
	
	$base = mysql_connect ('localhost', 'root', '');
	mysql_select_db ('platform', $base) ;

	$sql = 'SELECT auteur, message, date_reponse FROM forum_reponses WHERE correspondance_sujet="'.$_GET['id_sujet_a_lire'].'" ORDER BY date_reponse ASC';

	$req = mysql_query($sql) or die('Erreur SQL !<br />'.$sql.'<br />'.mysql_error());


	while ($data = mysql_fetch_array($req)) {

		sscanf($data['date_reponse'], "%4s-%2s-%2s %2s:%2s:%2s", $annee, $mois, $jour, $heure, $minute, $seconde);


		echo '<tr>';
		echo '<td>';


		echo htmlentities(trim($data['auteur']));
		echo '<br />';
		echo $jour , '-' , $mois , '-' , $annee , ' ' , $heure , ':' , $minute;

		echo '</td><td>';


		echo nl2br(htmlentities(trim($data['message'])));
		echo '</td></tr>';
	}

	mysql_free_result ($req);

	mysql_close ();
	?>

	
	</table>
	<br /><br />
	
	<a href="./insert_reponse.php?numero_du_sujet=<?php echo $_GET['id_sujet_a_lire']; ?>">R�pondre</a>
	<?php
}
?>
<br /><br />

<a href="./session2.php">Retour � l'accueil</a>

</body>
</html>