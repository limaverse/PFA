<?php 

include("../inc/base.php");
session_start();
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];

if($profile=='etudiant'){
$login= $_SESSION['user'];
$sql2="SELECT m.id,m.nom from  module m ,etudiant e ,personnes p  where p.id=e.id_personne and e.id_form=m.id_form and  login='$login'";
$res2=mysqli_query($con,$sql2);

?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>cours</title>
	</head>
	
	<body>
	<div id='page'>
<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="module.php">module</a></li>  
	<li><a href="home.php">retour</a></li>  
	</ul>
	</div>
	<div id="corp">
	<table  border="2" id="tab1"><CAPTION>..formation..</CAPTION>
 	   <TH>cours</TH>

<?php
if(isset($_POST['mod'])){
$mod=$_POST['mod'];
$sql3="select * from cours where id_module='$mod'";
$res3=mysqli_query($con,$sql3);
while($tab=mysqli_fetch_array($res3,MYSQLI_BOTH)){ ?>

  <tr><td><a href="<?php echo $tab['dossier']?>/<?php echo $tab['fichier']?>"><?php echo $tab['nom']?></a></td></tr>
      
	  <?php } }?>
	  </table> 
	<form id="module" method="post" >
			<fieldset>
				<legend>choisir vos modules</legend>
				<select name="mod" >
				<?php while($donne1=mysqli_fetch_array($res2,MYSQLI_BOTH)){ ?>
                
               <option value="<?php echo $donne1['id']; ?>" ><?php echo $donne1['nom']; ?></option>
               			   <?php } ?>
               </select>
  <input type="submit"   name="module" value="choisir"/>			   
			   </fieldset>			
		       </form> 
	
	
	


</div>
<div id="pied"></div>
	</body>
</html>


<?php
}

?>
