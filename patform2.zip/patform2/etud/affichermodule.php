<?php 

include("../inc/base.php");
session_start();
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];

if($profile=='etudiant'){

$login= $_SESSION['user'];
$sql="SELECT m.nom,m.duree,m.coef from  module m ,etudiant e ,personnes p  where p.id=e.id_personne and e.id_form=m.id_form and  login='$login'";
$res=mysqli_query($con,$sql);

?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>module</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">
	<ul>

	<li><a href="module.php">retour</a></li>  
	</ul>
	</div>
	<div id="corp">
	
	<table  border="2" id="tab1"><CAPTION>..modules..</CAPTION>
 	   <TH>module</TH> <TH>duree</TH>  <TH>coef</TH>
<?php 

while($tab=mysqli_fetch_array($res,MYSQLI_BOTH)){ ?>

  <tr><td><?php echo $tab['nom'] ; ?></td><td><?php echo $tab['duree']?></td><td><?php echo $tab['coef']; ?></td></tr>
      
	  <?php  }?>
	  </table> 
	  <form id="affi" method="post" action="affichercour.php" >
			<fieldset>
				<legend>choisissez un module</legend>
				
				
                <select name="module" >
				
				<?php 
			
				$sql="SELECT m.nom,m.duree,m.coef from  module m ,etudiant e ,personnes p  
				where p.id=e.id_personne and e.id_formation=m.id_formation and  login='$login'";
				$res=mysqli_query($con,$sql);?>
				<?php 
				while($tab=mysqli_fetch_array($res,MYSQLI_BOTH)){ ?>
                <option value="<?php echo $tab['id']; ?>" ><?php echo $tab['nom']; ?></option>
                <?php } ?>
               </select>
              
			<input type="submit"   name="aff" value="voir"/>				
			</fieldset>			
		</form>
	
	
	
	</div>
<div id="pied"></div>
	</body>
</html>

<?php }



?>
