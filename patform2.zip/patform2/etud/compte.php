<?php

session_start();// d�marrer une session
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];
?>




<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>compte</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">

	<ul>
	
 
<li><a href="modmdp.php">modifier mot de passe</a></li> 
<li><a href="home.php">accueil</a></li> 
	</ul >
	</div>
	<div id="corp">
	</div>
<div id="pied"></div>
	</body>
</html>
