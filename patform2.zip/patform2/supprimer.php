<?php 
try{
include("div\base.php");
session_start();// d�marrer une session

$profile= $_SESSION['profile'];
$nom= $_SESSION['nom'];
if ($profile=='admin'){
?>
<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>modification des comptes</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">	<ul >

    <li><a href="compte.php">compte</a></li> 
    <li><a href="session2.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
	 <form id="recherche" method="post">
			<fieldset>
				<legend>supprimer</legend>
				<label for="login">user: </label><input type="text" id="login" name="login" /><br />
				<input type="submit"  id="supp" name="supp" value="supprimer"/>				
			</fieldset>			
		</form>
		<?php
if (!empty($_POST['login']) )
$user=$_POST['login'];
if(isset($_POST['supp'])){
$x=0;
$resulta=$bdd->query('select login from personnes ');

while($donne=$resulta->fetch()){
if($donne['login']==$user){
$reponce5=$bdd->prepare('delete from personnes where login=?');

$reponce5->execute(array( $user));
echo 'compte supprimer';
$x=1;
break;
}
}

if($x==0)
echo 'compte n \'existe pas';

}}
?>
	</div><div id="pied"></div></div>
	</body>
</html>
<?php
if ($profile=='scolarite'){
?>
<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>modification des comptes</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">	<ul >

    <li><a href="compte.php">compte</a></li> 
    <li><a href="session2.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
	 <form id="recherche" method="post">
			<fieldset>
				<legend>supprimer</legend>
				<label for="login">user: </label><input type="text" id="login" name="login" /><br />
				<input type="submit"  id="supp" name="supp" value="supprimer"/>				
			</fieldset>			
		</form>
		<?php
if (!empty($_POST['login']) )
$user=$_POST['login'];
if(isset($_POST['supp'])){
$x=0;
$resulta=$bdd->query('select login from personnes where profile="professeur" or profile="etudiant"');

while($donne=$resulta->fetch()){
if($donne['login']==$user){
$reponce5=$bdd->prepare('delete from personnes where login=?');

$reponce5->execute(array( $user));
echo 'compte supprimer';
$x=1;
break;
}
}

if($x==0)
echo 'compte n \'existe pas';

}}}
catch(Exception $e){
echo 'Error:'.$e->getmessage();}
?>
	</div><div id="pied"></div></div>
	</body>
</html>