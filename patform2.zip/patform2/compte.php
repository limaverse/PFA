<?php

session_start();// d�marrer une session
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];
?>




<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>compte</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu"
<?php
 if($profile=="scolarite"){?>

	<br/>
	<ul >
	
<li><a href="ajout.php">ajouter</a></li>  
<li><a href="modifier_compte.php">modifier</a></li> 
<li><a href="modmdp.php">modifier mot de passe</a></li> 
<li><a href="supprimer.php">supprimmer</a></li>  
<li><a href="recherche.php">recherecher</a></li>
<li><a href="session2.php">accueil</a></li> 
	</ul >
	</div>
	<div id="corp">
	</div>
<div id="pied"></div>
	</body>
</html>

<?php
}
else if($profile=="admin"){?>

	</br>
	<ul >
	
<li><a href="ajout.php">ajouter</a></li> 
<li><a href="supprimer.php">supprimmer</a></li>
<li><a href="recherche.php">afficher les comptes</a></li> 
<li><a href="modmdp.php">modifier mot de passe</a></li> 
<li><a href="session2.php">accueil</a></li> 
	</ul >
	</div>
	<div id="corp">
	</div>
<div id="pied"></div>
	</body>
</html>
<?php
} 
else if($profile=="etudiant" ||$profile=="professeur"){?>

	</br>
	<ul >
	
 
<li><a href="modmdp.php">modifier mot de passe</a></li> 
<li><a href="session2.php">accueil</a></li> 
	</ul >
	</div>
	<div id="corp">
	</div>
<div id="pied"></div>
	</body>
</html>
<?php
} ?>