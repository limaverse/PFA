<?php 
try{
include("div\base.php");
session_start();
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];


if($profile=='scolarite'){
$reponce3=$bdd->query('select * from formation');
?>
<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>notes</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="session2.php">retour</a></li>  
	</ul>
	</div>
	<div id="corp">
	<table  border="2" id="tab1"><CAPTION>..formation..</CAPTION>
 	   <TH>formation</TH> <TH>duree</TH> 
<?php 
while($tab=$reponce3->fetch()){ ?>
  <tr><td><?php echo $tab['nom_form']?></td><td><?php echo $tab['duree']?></td></tr>
       <?php } ?>
	  </table> 
	<form id="affi" method="post"  >
			<fieldset>
				<legend>choisissez une formation</legend>
                <select name="form" >
				<?php $reponce3=$bdd->query('select * from formation');
				while($tab=$reponce3->fetch()){ ?>
                <option value="<?php echo $tab['id']; ?>" ><?php echo $tab['nom_form']; ?></option>
                <?php } ?>
               </select>
			<input type="submit"   name="aff" value="voir"/>				
			</fieldset>			
		</form>
<?php	
if(isset($_POST['form'])){
$form=$_POST['form'];
$reponce3=$bdd->prepare('select * from module where id_form=?');
$reponce3->execute(array( $form));
?>
	<table  border="2" id="tab1"><CAPTION>..modules..</CAPTION>
 	   <TH>module</TH> <TH>duree</TH>  <TH>coef</TH>
<?php 
while($tab=$reponce3->fetch()){ ?>
  <tr><td><?php echo $tab['nom']?></td><td><?php echo $tab['duree']?></td><td><?php echo $tab['coef']?></td></tr> 
	  <?php } ?>
	  </table> 
	  <form id="affi" method="post" action="affichernote2.php" >
			<fieldset>
				<legend>choisissez un module</legend>
                <select name="mod" >
				<?php 
				$reponce3=$bdd->prepare('select * from module where id_form=?');
				$reponce3->execute(array( $form));?>
				<?php 
				while($tab=$reponce3->fetch()){ ?>
                <option value="<?php echo $tab['id']; ?>" ><?php echo $tab['nom']; ?></option>
                <?php } ?>
               </select>
			<input type="submit"   name="aff" value="voir"/>				
			</fieldset>			
		</form><?php } ?>
	</div>
<div id="pied"></div>
	</body>
</html>
<?php
}
if($profile=='etudiant'){
$login= $_SESSION['user'];
$reponce3=$bdd->prepare('SELECT m.id,m.nom,e.id_personne from  module m ,etudiant e ,personnes p  where p.id=e.id_personne and e.id_form=m.id_form and  login=?');
$reponce3->execute(array( $login));

?>
<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>notes</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php echo "bonjour"." ".$nom;?> <a href="deconnexion.php">deconnexion</a></div>
	<div id="menu">
	<ul>

	<li><a href="session2.php">retour</a></li>  
	</ul>
	</div>
	<div id="corp">
	<table  border="2" id="tab1"><CAPTION>..vos notes..</CAPTION>
 	   <TH>module</TH><TH>examen</TH><TH>ratrapage</TH>
<?php 
while($donne1=$reponce3->fetch()){
$module=$donne1['id'];
$id_etud=$donne1['id_personne'];
?>
<tr>
<?php
$reponce2=$bdd->prepare('select m.nom,n.examen,n.ratrapage from notes n , module m where m.id=n.id_module and n.id_module=? and n.id_etudiant=?');
$reponce2->execute(array( $module,$id_etud));

while($tab=$reponce2->fetch()){ ?>
<td><?php echo $tab['nom'] ;?></td><td><?php echo $tab['examen'] ;?></td><td><?php echo $tab['ratrapage'] ;?></td></tr>
      
	  <?php } ?>
	  </table> 

</div>
<div id="pied"></div>
	</body>
</html>
<?php
}
}
if($profile=='professeur'){
$login= $_SESSION['user'];
$reponce3=$bdd->prepare('SELECT m.id,m.nom,f.nom_form from module m,personnes p,formation f WHERE m.id_professeur=p.id and f.id=m.id_form and p.login=?');
$reponce3->execute(array( $login));
?>
<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>compte</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="session2.php">retour</a></li>  
	
	</ul>
	</div>
	<div id="corp">
	<form id="formation" method="post" >
<fieldset>
				<legend>choix des modules</legend>
				<select name="mod" >
				<?php while($donne1=$reponce3->fetch()){ ?>
                
               <option value="<?php echo $donne1['id']; ?>" ><?php echo $donne1['nom']; ?> *** <?php echo $donne1['nom_form']; ?></option>
               			   <?php } ?>
               </select>
  <input type="submit"   name="ajout" value="choisir"/>			   
			   </fieldset>			
		       </form>

<?php



if(isset($_POST['mod'])){
$module=$_POST['mod'];
$reponce3=$bdd->prepare('SELECT p.nom, p.prenom, n.examen,n.ratrapage FROM module m, etudiant e, personnes p, notes n WHERE p.id = e.id_personne AND e.id_form = m.id_form AND m.id = n.id_module AND m.id =?');
$reponce3->execute(array($module));
?>

	<table  border="2" id="tab1"><CAPTION>..formation..</CAPTION>
 	   <TH>nom</TH><TH>prenom</TH><TH>examen</TH><TH>ratrapage</TH>
<?php 

while($tab=$reponce3->fetch()){ ?>

  <tr><td><?php echo $tab['nom']?></td><td><?php echo $tab['prenom']?></td><td><?php echo $tab['examen']?></td><td><?php echo $tab['ratrapage']?></td></tr>
      
	  <?php } ?>
	  </table> 
	
	


</div>
<div id="pied"></div>
	</body>
</html>
<?php



}}}

	
catch(Exception $e){
echo 'Error:'.$e->getmessage();}?>