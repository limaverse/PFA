<?php

if (isset ($_POST['go']) && $_POST['go']=='Poster') {

	if (!isset($_POST['auteur']) || !isset($_POST['titre']) || !isset($_POST['message'])) {
		$erreur = 'Les variables n�cessaires au script ne sont pas d�finies.';
	}
	else {
		
		if (empty($_POST['auteur']) || empty($_POST['titre']) || empty($_POST['message'])) {
			$erreur = 'Au moins un des champs est vide.';
		}

		else {
			
			$base = mysql_connect ('localhost', 'root', '');
			mysql_select_db ('platform', $base) ;

		
			$date = date("Y-m-d H:i:s");

			
			$sql = 'INSERT INTO forum_sujets VALUES("", "'.mysql_escape_string($_POST['auteur']).'", "'.mysql_escape_string($_POST['titre']).'", "'.$date.'")';

	
			mysql_query($sql) or die('Erreur SQL !'.$sql.'<br />'.mysql_error());

			$id_sujet = mysql_insert_id();

			$sql = 'INSERT INTO forum_reponses VALUES("", "'.mysql_escape_string($_POST['auteur']).'", "'.mysql_escape_string($_POST['message']).'", "'.$date.'", "'.$id_sujet.'")';

			mysql_query($sql) or die('Erreur SQL !'.$sql.'<br />'.mysql_error());

			mysql_close();

		
			header('Location: forum.php');

		
			exit;
		}
	}
}
?>
<html>
<head>
<title>Insertion d'un nouveau sujet</title>
</head>

<body>


<form action="insert_sujet.php" method="post">
<table>
<tr><td>
<span class="gras">Auteur :</span>
</td><td>
<input type="text" name="auteur" maxlength="30" size="50" value="<?php if (isset($_POST['auteur'])) echo htmlentities(trim($_POST['auteur'])); ?>">
</td></tr><tr><td>
<span class="gras">Titre :</span>
</td><td>
<input type="text" name="titre" maxlength="50" size="50" value="<?php if (isset($_POST['titre'])) echo htmlentities(trim($_POST['titre'])); ?>">
</td></tr><tr><td>
<span class="gras">Message :</span>
</td><td>
<textarea name="message" cols="50" rows="10"><?php if (isset($_POST['message'])) echo htmlentities(trim($_POST['message'])); ?></textarea>
</td></tr><tr><td><td align="right">
<input type="submit" name="go" value="Poster">
</td></tr></table>
</form>
<?php

if (isset($erreur)) echo '<br /><br />',$erreur;
?>
</body>
</html>