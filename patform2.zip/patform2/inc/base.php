<?php 
$con=mysqli_connect("localhost","root","","platform") or die("erreur");

?>