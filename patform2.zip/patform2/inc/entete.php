
<div id="en_tete">
<center>
<?php
 echo "bonjour"." ".$nom;?> <a href="../deconnexion.php">deconnexion</a>


</div>