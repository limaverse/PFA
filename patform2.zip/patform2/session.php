<?php 
session_start();

if (!empty($_POST['pass']) && !empty($_POST['login']) ){

$pass=$_POST['pass'];
$login=$_POST['login'];

include("inc\base.php");

$sql="select login,pass,profile,nom from personnes";
$x=0;

if($resulta=mysqli_query($con,$sql)){


while($donne=mysqli_fetch_array($resulta,MYSQLI_BOTH)){

if($pass==$donne['pass'] && $login==$donne['login']){

$profile=$donne['profile'];
$nom=$donne['nom'];
$_SESSION['nom']=$nom;
$_SESSION['profile']=$profile;
$_SESSION['user']=$login;
$x=1;
}
}
}

if ($profile == 'admin') {
			header('location: admin/home.php');		  
		}
		else if ($profile == 'professeur'){
			header('location: prof/home.php');
		}
		else if ($profile == 'etudiant'){
			header('location: etud/home.php');
		}
		else if ($profile == 'scolarite'){
			header('location: scol/home.php');
		}
 

if($x==0)
{
 header('Location:index.php');  
}


}
?>