<?php 

include("div\base.php");
session_start();// d�marrer une session

$profile= $_SESSION['profile'];
$profile2=$_SESSION['profile2'];
$nom= $_SESSION['nom'];
if ($profile2=='professeur'){

?>

<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>modification des comptes</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">	<ul > 

	<li><a href="compte.php">compte</a></li> 
	<li><a href="session2.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
		<form id="modifier" method="post" >
			<fieldset> 
				<legend>ajouter</legend>
				
				<label for="nom">nom: </label><input type="text" id="nom" name="nom"  /><br />
				<label for="prenom">prenom : </label><input type="text" id="prenom" name="prenom" /><br />
				<label for="login">user: </label><input type="text"id="user" name="user"  /><br />
				<label for="telephone">telephone: </label><input type="text" id="telephone" name="telephone"  /><br />
				<label for="adresse">adresse: </label><input type="text" id="adresse" name="adresse" /><br />
				<label for="email">email: </label><input type="email" id="email" name="email" /><br />
				<input type="submit"   name="ajout" value="ajouter"/>				
			</fieldset>			
		</form>
		
		
	
<?php
if (!empty($_POST['user']) )
$user=$_POST['user'];

if(isset($_POST['ajout'])){
$resulta=mysqli_query($con,'select login from personnes ');
while($donne=mysqli_fetch_array($resulta,MYSQLI_BOTH)){
$x=0;
if($donne['login']==$user){
$x=1;
BREAK;
}}
if($x==1){
echo 'compte existe deja';
}

if($x==0){
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];

$tel=$_POST['telephone'];
$adr=$_POST['adresse'];
$email=$_POST['email'];


$sql="insert into personnes(login,pass,profile,nom,prenom,adresse,email,tel)values('$user','$prenom','$profile2','$nom','$prenom','$adr','$email','$tel')";

$res=mysqli_query($con,$sql);

$id=mysqli_insert_id($con); 

$sql1="insert into professeur (id_personne)values('$id')";

$res1=mysqli_query($con,$sql1); 

echo 'compte ajout� avec succ�s ';




}

}
}

else if ($profile2=='etudiant'){
$res2=mysqli_query($con,'select * from formation');

?>

<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>modification des comptes</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">	<ul > 

	<li><a href="compte.php">compte</a></li> 
	<li><a href="session2.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
		<form id="modifier" method="post" >
			<fieldset>
				<legend>ajouter</legend>
				
				<label for="nom">nom: </label><input type="text" id="nom" name="nom"  /><br />
				<label for="prenom">prenom : </label><input type="text" id="prenom" name="prenom" /><br />
				<label for="login">user: </label><input type="text"id="user" name="user"  /><br />
				<label for="telephone">telephone: </label><input type="text" id="telephone" name="telephone"  /><br />
				<label for="adresse">adresse: </label><input type="text" id="adresse" name="adresse" /><br />
				<label for="email">email: </label><input type="email" id="email" name="email" /><br />
				<select name="form" >
             <?php while($donne=mysqli_fetch_array($res2,MYSQLI_BOTH)){ ?>
                
               <option value="<?php echo $donne['id']; ?>" ><?php echo $donne['nom_form']; ?></option>
               
			   <?php } ?>
               </select>
				<input type="submit"   name="ajout" value="ajouter"/>				
			</fieldset>			
		</form>
		
		
	
<?php
if (!empty($_POST['user']) )
$user=$_POST['user'];

if(isset($_POST['ajout'])){
$resulta=mysqli_query($con,'select login from personnes ');
while($donne=mysqli_fetch_array($resulta,MYSQLI_BOTH)){
$x=0;
if($donne['login']==$user){
$x=1;
BREAK;
}}
if($x==1)
echo 'compte existe deja';
if($x==0){
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];

$tel=$_POST['telephone'];
$adr=$_POST['adresse'];
$email=$_POST['email'];
$form=$_POST['form'];


$sql2="insert into personnes(login,pass,profile,nom,prenom,adresse,email,tel)values('$user','$prenom','$profile2','$nom','$prenom','$adr','$email','$tel')";

$res3=mysqli_query($con,$sql2);


$id=mysqli_insert_id($con);

$sql3="insert into etudiant(id_personne,id_form)values('$id','$form')";

$res4=mysqli_query($con,$sql3);


echo 'compte ajout� avec succ�s';


}

}

}