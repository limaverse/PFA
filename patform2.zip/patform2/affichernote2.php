<?php 
try{
include("div\base.php");
session_start();
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];


if($profile=='scolarite'){
$module=$_POST['mod'];

$_SESSION['module1']=$module;
?>
<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>notes</title>
	</head>
	
	<body>
	<div id='page'>
<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">
	<ul>
	
	<li><a href="session2.php">retour</a></li>  
	</ul>
	</div>
	<div id="corp">
	<?php 


$reponce3=$bdd->prepare('SELECT p.nom, p.prenom, n.examen,n.ratrapage FROM module m, etudiant e, personnes p, notes n WHERE p.id = e.id_personne AND e.id_form = m.id_form AND m.id = n.id_module and
 e.id_personne=n.id_etudiant AND m.id =?');
$reponce3->execute(array($module));
?>

	<table  border="2" id="tab1"><CAPTION>..notes..</CAPTION>
 	   <TH>nom</TH><TH>prenom</TH><TH>exament</TH><TH>ratrapage</TH>
<?php 

while($tab=$reponce3->fetch()){ ?>

  <tr><td><?php echo $tab['nom']?></td><td><?php echo $tab['prenom']?></td><td><?php echo $tab['examen']?></td><td><?php echo $tab['ratrapage']?></td></tr>
      
	  <?php } ?>
	  </table> 
	<form  method="post"  action="ajoutnote.php" >
			<fieldset>
				<legend>cliquer ajouter </legend>
                
			<input type="submit"   name="aff" value="ajouter"/>				
			</fieldset>			
		</form>

	
	
	

	



</div>
<div id="pied"></div>
	</body>
</html>



<?php
}


}
	
catch(Exception $e){
echo 'Error:'.$e->getmessage();}?>