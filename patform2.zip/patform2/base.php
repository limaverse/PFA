<?php 
$con=mysqli_connect("localhost","root","","platform");

session_start();
$nom= $_SESSION['nom'];?>