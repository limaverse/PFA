<?php
	// Initialiser la session
	session_start();
	// Vérifiez si l'utilisateur est connecté, sinon redirigez-le vers la page de connexion
	if(!isset($_SESSION["user"])){
		header("Location: index.php");
		exit(); 
	}
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];
$login= $_SESSION['user'];
?>
<!DOCTYPE html>
<html>
	<head>
	<link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
	</head>
		
		<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="compte.php">compte</a></li>  
	<li><a href="discution.php">discution</a></li>  
	<li><a href="../logout.php">Déconnexion</a></li>
		</ul>
		</div>
		
		<div id="corp">
	  


	  
	</div>
	<div id="pied"></div>
	</body>
</html>