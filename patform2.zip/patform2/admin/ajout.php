<?php 

include("div\base.php");
session_start();// d�marrer une session

$profile= $_SESSION['profile'];
$nom= $_SESSION['nom'];
if ($profile=='admin'){




?>

<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>modification des comptes</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">	<ul > 

	<li><a href="compte.php">compte</a></li> 
	<li><a href="session2.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
		<form id="modifier" method="post" >
			<fieldset>
				<legend>ajouter</legend>
				
				<label for="nom">nom: </label><input type="text" id="nom" name="nom"  /><br />
				<label for="prenom">prenom : </label><input type="text" id="prenom" name="prenom" /><br />
				<label for="login">user: </label><input type="text"id="user" name="user"  /><br />
				<label for="telephone">telephone: </label><input type="text" id="telephone" name="telephone"  /><br />
				<label for="adresse">adresse: </label><input type="text" id="adresse" name="adresse" /><br />
				<label for="email">email: </label><input type="email" id="email" name="email" /><br />
				<select name="profile" >
              
               <option>scolarite</option> 
			   
               </select>
				<input type="submit"   name="ajout" value="ajouter"/>				
			</fieldset>			
		</form>
		
		
	
<?php
if (!empty($_POST['user']) )
$user=$_POST['user'];

if(isset($_POST['ajout'])){
$sql="select login from personnes";
$resulta=mysqli_query($con,$sql);
while($donne=mysqli_fetch_array($resulta,MYSQLI_BOTH)){
$x=0;
if($donne['login']==$user){
$x=1;
BREAK;
}}
if($x==1)
echo 'compte existe deja';
if($x==0){
$nom=$_POST['nom'];
$prenom=$_POST['prenom'];

$tel=$_POST['telephone'];
$adr=$_POST['adresse'];
$email=$_POST['email'];
$profile=$_POST['profile'];

$req="insert into personnes(login,pass,profile,nom,prenom,adresse,email,tel)values('$user','$prenom','$profile','$nom','$prenom','$adr','$email','$tel')";

$res=mysqli_query($con,$req);


echo 'compte ajout� avec succ�s';


}

}}
else if ($profile=='scolarite'){




?>

<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>modification des comptes</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">	<ul > 

	<li><a href="compte.php">compte</a></li> 
	<li><a href="session2.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
		<form id="modifier" method="post" >
			<fieldset>
				<legend>ajouter</legend>
				
			
				<select name="profile" >
             
                
               <option>professeur</option>
               <option>etudiant</option>
			   
               </select>
				<input type="submit"   name="ajout" value="ajouter"/>				
			</fieldset>			
		</form>
		
		
	
<?php
if(isset($_POST['ajout'])){

$profile2=$_POST['profile'];
$_SESSION['profile2']=$profile2;

 header('Location:ajoutforrm.php'); 
}}

?>
	</div><div id="pied"></div></div>
	</body>
</html>