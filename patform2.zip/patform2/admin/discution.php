<?php 
session_start();
$nom= $_SESSION['nom'];
?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>compte</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="session2.php">accueil</a></li>  
	<li><a href="chat.php">chat</a></li> 
	<li><a href="forum.php">forum</a></li> 
    
	</ul>
	</div>
	<div id="corp">
	</div>
<div id="pied"></div>
	</body>
</html>