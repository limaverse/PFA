<?php try
{
include("div\base.php");
session_start();
$nom= $_SESSION['nom'];
?>
    <html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />

<META HTTP-EQUIV="Refresh" CONTENT="10; URL=http://127.0.0.1:8888/platform/chat.php"> 


<title>compte</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="session2.php">accueil</a></li>  
	
    
	</ul>
	</div>
	<div id="corp">
    
    <form action="chat2.php" method="post">
        <p>
        
        <label for="message">Message</label> :  <input type="text" name="message" id="message" /><br />

        <input type="submit" value="Envoyer" />
	</p>
    </form>


<?php


    
    
    $reponse = $bdd->query('SELECT pseudo, message FROM chat ORDER BY ID DESC LIMIT 0, 10');
    
 ?>
<table  border="2" id="tab1"><CAPTION>bien venu au chat</CAPTION>
 	   <TH>message</TH>
	   
	   
   <?php while ($donne= $reponse->fetch())
    {?>
	<tr ><td> <?php echo $donne['pseudo'].'  a dit :'.$donne['message']?></td></tr>
    <?php  
    }
    

}
catch(Exception $e)
{
    die('Erreur : '.$e->getMessage());
}

?>

	</div>
</div>
	</body>
</html>