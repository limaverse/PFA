<?php 


include("../inc/base.php");
session_start();
$nom= $_SESSION['nom'];

$profil= $_SESSION['profile'];
if($profil=='scolarite'){

$res=mysqli_query($con,'select * from formation');
?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>compte</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="formation.php">retour</a></li>  
	
	
	</ul>
	</div>
	<div id="corp">
	<table  border="2" id="tab1"><CAPTION>..formation..</CAPTION>
 	   <TH>formation</TH> <TH>duree</TH> 
<?php 

while($tab=mysqli_fetch_array($res,MYSQLI_BOTH)){ ?>

  <tr><td><?php echo $tab['nom_form']?></td><td><?php echo $tab['duree']?></td></tr>
      
	  <?php } ?>
	  </table> 
	  
	<form id="affi" method="post" action="affichermodule.php" >
			<fieldset>
				<legend>choisissez une formation</legend>
				
				
                <select name="form" >
				<?php $res=mysqli_query($con,'select * from formation');
				while($tab=mysqli_fetch_array($res,MYSQLI_BOTH)){ ?>
                <option value="<?php echo $tab['id']; ?>" ><?php echo $tab['nom_form']; ?></option>
                <?php } ?>
               </select>
              
			<input type="submit"   name="aff" value="voir"/>				
			</fieldset>			
		</form>
	
	
	</div>
<div id="pied"></div>
	</body>
</html>
<?php
}

?>