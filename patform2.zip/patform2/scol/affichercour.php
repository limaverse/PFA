<?php 

include("../inc/base.php");
session_start();
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];


if($profile=='scolarite'){
$module=$_POST['module'];
$sql="select * from cours where id_module='$module'";
$res=mysqli_query($con,$sql);
?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>cours</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="module.php">module</a></li>  
	<li><a href="home.php">retour</a></li>  
	</ul>
	</div>
	<div id="corp">
	<table  border="2" id="tab1"><CAPTION>..formation..</CAPTION>
 	   <TH>cours</TH>
<?php 

while($tab=mysqli_fetch_array($res,MYSQLI_BOTH)){ ?>

  <tr><td><a href="<?php echo $tab['dossier']?>/<?php echo $tab['fichier']?>"><?php echo $tab['nom']?></a></td></tr>
      
	  <?php } ?>
	  </table> 
	 
	
	
	

	



</div>
<div id="pied"></div>
	</body>
</html>



<?php
}


?>
