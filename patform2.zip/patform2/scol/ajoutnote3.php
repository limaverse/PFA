<?php 

include("../inc/base.php");

session_start();

$module=$_SESSION['module1'];

$id_etud=$_SESSION['etud'];

$nom= $_SESSION['nom'];

$profile= $_SESSION['profile'];




unset($_SESSION['etud']);
$note=$_POST['note'];
$obs=$_POST['obs'];


?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>notes</title>
	</head>
	
	<body>
	<div id='page'>
<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">
	</div>
	<div id="corp">
	<?php  
if($obs=='exm'){
$sql="insert into notes (id_module,id_etudiant,examen) values ('$module','$id_etud','$note')";

$res=mysqli_query($con,$sql);}	
else if($obs=='rat'){
$sql="UPDATE notes SET ratrapage='$note'  WHERE id_module='$module' and id_etudiant='$id_etud'";

$res=mysqli_query($con,$sql);}
?>
	<li><a href="ajoutnote.php">ajouter une autre note</a></li> 
	<li><a href="home.php">accueil</a></li> 
	</div>
<div id="pied"></div>
	</body>
</html>
