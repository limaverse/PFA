<?php 

include("../inc/base.php"); 
session_start();
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];
if($profile=='scolarite'){
?> 
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>modifier formation</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">	<ul > 
	<li><a href="formation.php">formation</a></li> 
	<li><a href="home.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
		<form id="modifier" method="post" >
			<fieldset>
				<legend>modifier</legend>
				<label for="nom">nom de la formation: </label><input type="text" id="nom" name="nom"  /><br />
				<label for="nom1">modifier le nom: </label><input type="text" id="nom1" name="nom1"  /><br />
				<label for="duree">modifier la duree de la formation: </label><input type="text" id="duree" name="duree"  /><br />
			<input type="submit"   name="mod" value="modifier"/>				
			</fieldset>			
		</form>
<?php
$x=0;

if(isset($_POST['mod'])){
$nom=$_POST['nom'];
$nom1=$_POST['nom1'];

$duree=$_POST['duree'];

$sql="select * from formation where nom_form='$nom'";;
$res=mysqli_query($con,$sql);
while($donne1=mysqli_fetch_array($res,MYSQLI_BOTH)){
if($donne1['nom_form']==$nom){
$x=1;
break;
}

}
if($x==1 && $nom!=$nom1){
$sql="UPDATE formation SET nom_form='$nom1' ,duree='$duree'  WHERE nom_form='$nom'";
$res=mysqli_query($con,$sql);
echo 'formation'.$nom.'modifiée avec succès  ' ;}
else if($nom!=$nom1) {
echo 'erreur modification';
}

if( $x==1 && $nom==$nom1){
$sql="UPDATE formation SET duree='$duree'  WHERE nom_form='$nom'";
$res=mysqli_query($con,$sql);
echo 'durée formation'.$nom .'modifiée avec succès  ' ;}

}
}



?>