<?php 

include("../inc/base.php");
session_start();// d�marrer une session

$profile= $_SESSION['profile'];
$nom= $_SESSION['nom'];

?>



<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>modification des comptes</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">	<ul > 

	<li><a href="compte.php">compte</a></li> 
	<li><a href="home.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
		<form id="modifier" method="post" >
			<fieldset>
				<legend>ajouter</legend>
				
			
				<select name="profile" >
             
                
               <option>professeur</option>
               <option>etudiant</option>
			   
               </select>
				<input type="submit"   name="ajout" value="ajouter"/>				
			</fieldset>			
		</form>
		
		
	
<?php
if(isset($_POST['ajout'])){

$profile2=$_POST['profile'];
$_SESSION['profile2']=$profile2;

 header('Location:ajoutforrm.php'); 
}

?>
	</div><div id="pied"></div></div>
	</body>
</html>