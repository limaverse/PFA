<?php 

include("../inc/base.php");

session_start();

$nom= $_SESSION['nom'];

$profile= $_SESSION['profile'];



$module=$_SESSION['module1'];

$id_etud=$_POST['info'];
$_SESSION['etud']=$id_etud;

?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>notes</title>
	</head>
	
	<body>
	<div id='page'>
<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="ajoutnote.php">retour</a></li>
	<li><a href="home.php">acceuil</a></li>  
	</ul>
	</div>
	<div id="corp">
	
	<form id="formation" method="post"  action="ajoutnote3.php">
			<fieldset>
				<legend>notes</legend>
				
	
	<?php 


$sql="select examen,ratrapage from notes where id_module='$module' and id_etudiant='$id_etud'";

$res=mysqli_query($con,$sql);
$x=0;
$ii=0;
$h=0;
		 while($tab=mysqli_fetch_array($res,MYSQLI_BOTH)){
		 $h=1;
			
			  if($tab['examen']<=10){
			  if($tab['ratrapage']==0){
			  $ii=1;
			    ?>
			  <select name='obs'>
			  <option value="rat">ratrapage</option> 
			  <?php
			  $ii=1;
			  }}}
			  if ($h==0){
			  $x=1;
			  ?>
			 <select name='obs'>
			  <option value="exm">examen</option>
			  <?php
			  }
			  
			  
			   
			   
			  ?>
              </select>	
<?php
if(($ii==1 && $x==1) || ($ii==0 && $x==0) ){
			   echo "note  exist";
			  
}else if($x==0 && $ii==1){
echo 'inserer note ratrapage'	;}
else if($ii!=1 && $x==1 ){
echo'inserer note examen';}
			if(($x==0 && $ii==1) || ($x==1 && $ii==0) ){  
			  ?>			  
 <label for="note">note: </label><input type="text" id="note" name="note" /><br />			  
			  <input type="submit"   name="ajout" value="ajouter"/>
			  <?php
			} 
			  ?>
			</fieldset>			
		</form>
	<?php
	
	 

	
	
	?>
	
	
</div>
<div id="pied"></div>
	</body>
</html>



