<?php 

include("../inc/base.php");
session_start();
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];
if($profile=='scolarite'){
?> 
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>supprimer formation</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">	<ul > 
	<li><a href="formation.php">formation</a></li> 
	<li><a href="home.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
		<form id="ajoutf" method="post" >
			<fieldset>
				<legend>supprimmer</legend>
				<label for="nom">nom de la formation: </label><input type="text" id="nom" name="nom"  /><br />
			<input type="submit"   name="supp" value="supprimer"/>				
			</fieldset>			
		</form>
<?php
$x=0;
if(isset($_POST['supp'])){
$nom=$_POST['nom'];
$sql="select * from formation where nom_form='$nom'";
$res=mysqli_query($con,$sql);
while($donne1=mysqli_fetch_array($res,MYSQLI_BOTH)){
if($donne1['nom_form']==$nom){
$x=1;
$sql="delete from formation where nom_form='$nom'";
$res=mysqli_query($con,$sql);
break;
}}
if($x==1){
echo 'formation'.$nom.'supprimée avec succès';
}
else
echo 'formation n\'existe pas';}
}

?>