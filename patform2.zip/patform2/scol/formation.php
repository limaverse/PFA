<?php 

session_start();
$nom= $_SESSION['nom'];

?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>formation</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="ajoutform1.php">ajouter</a></li>  
	<li><a href="modifierform.php">modifier</a></li> 
	<li><a href="supprimerform.php">supprimer</a></li> 
	<li><a href="afficherformation.php">afficher</a></li>
    <li><a href="home.php">retour</a></li>  
	</ul>
	</div>
	<div id="corp">
	</div>
<div id="pied"></div>
	</body>
</html>