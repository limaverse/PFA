<?php 

 include("../inc/base.php"); 
session_start();
$nom= $_SESSION['nom'];


?> 
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>ajouter formation</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">	<ul > 

	<li><a href="formation.php">formation</a></li> 
	<li><a href="home.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
		<form id="ajoutf" method="post" >
			<fieldset>
				<legend>ajouter</legend>
				
				<label for="nom">nom de la formation: </label><input type="text" id="nom" name="nom"  /><br />
				<label for="duree">duree : </label><input type="text" id="duree" name="duree" /><br />
			<input type="submit"   name="ajout" value="ajouter"/>				
			</fieldset>			
		</form>
<?php

$x=0;
if(isset($_POST['ajout'])){
$nom1=$_POST['nom'];

$duree=$_POST['duree'];
$res1=mysqli_query($con,'select nom_form from formation');
while($donne1=mysqli_fetch_array($res1,MYSQLI_BOTH)){



if($donne1['nom_form']==$nom1){
$x=1;
break;

}}
if($x!=1){
$sql="insert into  formation(nom_form,duree) values('$nom1','$duree')";
$res2=mysqli_query($con,$sql);

echo 'formation  '.$nom1.'  ajoutée avec succès';

}
else
echo 'formation existe existe déja';

}




?>