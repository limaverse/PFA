<?php 


include("../inc/base.php");

session_start();

$nom= $_SESSION['nom'];

$profile= $_SESSION['profile'];

if($profile=='scolarite'){
	
$module=$_SESSION['module1'];
?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>notes</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">
	<ul>
	
	<li><a href="session2.php">retour</a></li>  
	</ul>
	</div>
	<div id="corp">
		<?php 

?>
	<form id="formation" method="post" action="ajoutnote2.php" >
			<fieldset>
				<legend>introduire vos notes</legend>
				<select name="info" >
	
	<?php 



$sql="SELECT p.nom, p.prenom, p.id FROM module m, etudiant e, personnes p WHERE p.id = e.id_personne AND e.id_form = m.id_form AND  m.id ='$module'";

$res=mysqli_query($con,$sql);
		 while($tab=mysqli_fetch_array($res,MYSQLI_BOTH)){
		 ?>
               <option value="<?php echo $tab['id']; ?>" ><?php echo $tab['nom'].'    '.$tab['prenom']; ?></option></br>
               
			   <?php } ?>
			   </select>
			  <input type="submit"   name="ajout" value="ajouter"/>
			   
			</fieldset>			
		</form>
		
		

</div>
<div id="pied"></div>
	</body>
</html>



<?php
}

?>