<?php 
try{
include("div\base.php");
session_start();
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];
if($profile=='scolarite'){
?> 
<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>supprimer formation</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">	<ul > 
	<li><a href="formation.php">formation</a></li> 
	<li><a href="session2.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
		<form id="ajoutf" method="post" >
			<fieldset>
				<legend>supprimmer</legend>
				<label for="nom">nom de la formation: </label><input type="text" id="nom" name="nom"  /><br />
			<input type="submit"   name="supp" value="supprimer"/>				
			</fieldset>			
		</form>
<?php
$x=0;
if(isset($_POST['supp'])){
$nom=$_POST['nom'];
$reponce1=$bdd->prepare('select * from formation where nom_form=?');
$reponce1->execute(array($nom));
while($donne1=$reponce1->fetch()){
if($donne1['nom']==$nom){
$x=1;
$reponce1=$bdd->prepare('delete from formation where nom_form=?');
$reponce1->execute(array($nom));
break;
}}
if($x==1){
echo 'formation'.$nom.'supprimer avec succes';
}
else
echo 'formation n\'existe pas';}
}}
catch(Exception $e){
echo 'Error:'.$e->getmessage();}
?>