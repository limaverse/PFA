
<?php 
try{
include("div\base.php");
session_start();// d�marrer une session
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];
if ($profile=="scolarite"){
?>
<html>
<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>modification des comptes</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">	<ul >
	
	<li><a href="compte.php">compte</a></li> 
	<li><a href="session2.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
	 <form id="recherche" method="post">
			<fieldset>
				<legend>rechercher</legend>
				<label for="nom">user: </label><input type="text" id="login" name="login" /><br />
				<input type="submit"  id="rech" name="rech" value="rechercher"/>				
			</fieldset>			
		</form>
	<?php
	
	if(isset($_POST['rech'])){
	$user=$_POST['login'];
	$_SESSION['user6']=$user;
   $reponce=$bdd->prepare("select * from personnes where  (login=?) and ((profile !='scolarite' ) and (profile !='admin' )  ) ");

   $reponce->execute(array ($_POST['login'],
                            )); 

while($donne=$reponce->fetch()){

?>




   
         <form id="modifier" method="post" action="modifier_compte2.php">
			<fieldset>
				<legend>modifier</legend>
				<label for="nom">nom: </label><input type="text" id="nom" name="nom" value="<?php echo $donne['nom'] ?>" /><br />
				<label for="prenom">prenom : </label><input type="text" id="prenom" name="prenom" value="<?php echo $donne['prenom'] ?>" /><br />
				<label for="login">user: </label><input type="text" readonly="readonly" id="user" name="user"  value="<?php echo $donne['login'] ?>" /><br />
				<label for="telephone">telephone: </label><input type="text" id="telephone" name="telephone" value="<?php echo $donne['tel'] ?>" /><br />
				<label for="adresse">adresse: </label><input type="text" id="adresse" name="adresse" value="<?php echo $donne['adresse'] ?>" /><br />
				<label for="email">email: </label><input type="email" id="email" name="email" value="<?php echo $donne['email'] ?>" /><br />
				<select name="profile" >
               <option><?php echo $donne['profile'] ?></option>
          
               <option>professeur</option>
               <option>etudiant</option>
			   
               </select>
				<input type="submit"   name="envoi2" value="modifier"/>				
			</fieldset>			
		</form>
		</div>
<div id="pied"></div>	
	</div>
	</body>
</html>
<?php
}}}



}




















catch(Exception $e){
echo 'Error:'.$e->getmessage();}

?>