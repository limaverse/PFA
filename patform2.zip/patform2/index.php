
<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css"  />
<title>connexion</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'></div>
	<div id="corp">
	
		<form name="login" id="ajouter" method="post" action="session.php">
			<fieldset>
				<legend>login</legend>
				
			    <label class="text-danger" for="nom">user: </label><input type="text" id="login" name="login" /><br />
				<label for="pw">password: </label><input type="password" id="pass" name="pass" /><br />
				<input type="submit"  name="verif" value="login"/>				
			</fieldset>			
		</form>
</div>
<div id="pied"></div>	
	</div>
	</body>
</html>