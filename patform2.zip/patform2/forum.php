<html>
<head>
<title>Index de notre forum</title>
</head>
<body>


<a href="./insert_sujet.php">Ins�rer un sujet</a>

<br /><br />

<?php

try{
include("div\base.php");





$reponce=$bdd->query('SELECT * FROM forum_sujets ORDER BY date_derniere_reponse DESC');





	?>
	<table width="500" border="1"><tr>
	<td>
	Auteur
	</td><td>
	Titre du sujet
	</td><td>
	Date derni�re r�ponse
	</td></tr>
	<?php

	$x=0;
while($data=$reponce->fetch()){
$x=1;

	sscanf($data['date_derniere_reponse'], "%4s-%2s-%2s %2s:%2s:%2s", $annee, $mois, $jour, $heure, $minute, $seconde);

	
	echo '<tr>';
	echo '<td>';


	echo htmlentities(trim($data['auteur']));
	echo '</td><td>';


	echo '<a href="./lire_sujet.php?id_sujet_a_lire=' , $data['id'] , '">' , htmlentities(trim($data['titre'])) , '</a>';

	echo '</td><td>';


	echo $jour , '-' , $mois , '-' , $annee , ' ' , $heure , ':' , $minute;
	}
	?>
	</td></tr></table>
	<?php
	if ($x== 0) {
	echo 'Aucun sujet';
}
}

catch(Exeption $e){
die('erreur:'.$e->getMessage());
}

?>
</body>
</html>