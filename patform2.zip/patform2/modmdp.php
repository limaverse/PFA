<?php try{
include("div\base.php");
session_start();// d�marrer une session
$nom= $_SESSION['nom'];
$user= $_SESSION['user'];
?>
<html>
<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>modification des comptes</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">	<ul > 
	<li><a href="compte.php">compte</a></li> 
	<li><a href="session2.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
	   
         <form id="modifier" method="post" >
			<fieldset>
				<legend>modifier</legend>
				<label for="pass">mot de passe: </label><input type="password" id="pass" name="pass"/><br />
			   <label for="pass1">nouveau mot de passe: </label><input type="password" id="pass1" name="pass1"/><br />
               </select>
				<input type="submit"   name="envoi2" value="modifier"/>				
			</fieldset>			
		</form>
<?php		
if(isset($_POST['envoi2'])){
$pass=$_POST['pass'];
$pass1=$_POST['pass1'];

$reponce4=$bdd->prepare('select pass from personnes WHERE login=?');
$reponce4->execute(array($user));
$donne=$reponce4->fetch();

if($pass==$donne['pass']){
$reponce5=$bdd->prepare('UPDATE personnes SET pass=? WHERE login=?');
$reponce5->execute(array( $pass1,$user));
echo'mot de passe modifier avec succes';
}
else echo'mote passe incorrecte';
}
		?></div>
<div id="pied"></div>	
	</div>
	</body>
</html>
<?php }

catch(Exception $e){
echo 'Error:'.$e->getmessage();}

?>