<?php try
{
  
   include("div\base.php");
session_start();
$nom= $_SESSION['nom'];

    
  
    $req = $bdd->prepare('INSERT INTO chat (pseudo, message) VALUES(?, ?)');
    $req->execute(array($nom, $_POST['message']));
    

    header('Location:chat.php');
}
catch(Exception $e)
{
    die('Erreur : '.$e->getMessage());
}
?>