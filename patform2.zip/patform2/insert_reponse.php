<?php

if (isset ($_POST['go']) && $_POST['go']=='Poster') {
	
	if (!isset($_POST['auteur']) || !isset($_POST['message']) || !isset($_GET['numero_du_sujet'])) {
		$erreur = 'Les variables n�cessaires au script ne sont pas d�finies.';
	}
	else {
		if (empty($_POST['auteur']) || empty($_POST['message']) || empty($_GET['numero_du_sujet'])) {
			$erreur = 'Au moins un des champs est vide.';
		}
		
		else {
		
			$base = mysql_connect ('localhost', 'root', '');
	mysql_select_db ('platform', $base) ;

			
			$date = date("Y-m-d H:i:s");

			
			$sql = 'INSERT INTO forum_reponses VALUES("", "'.mysql_escape_string($_POST['auteur']).'", "'.mysql_escape_string($_POST['message']).'", "'.$date.'", "'.$_GET['numero_du_sujet'].'")';

			
			mysql_query($sql) or die('Erreur SQL !'.$sql.'<br />'.mysql_error());

		
			$sql = 'UPDATE forum_sujets SET date_derniere_reponse="'.$date.'" WHERE id="'.$_GET['numero_du_sujet'].'"';

	
			mysql_query($sql) or die('Erreur SQL !'.$sql.'<br />'.mysql_error());

			mysql_close();

			header('Location: lire_sujet.php?id_sujet_a_lire='.$_GET['numero_du_sujet']);

			exit;
		}
	}
}
?>

<html>
<head>
<title>Insertion d'une nouvelle r�ponse</title>
</head>

<body>


<form action="insert_reponse.php?numero_du_sujet=<?php echo $_GET['numero_du_sujet']; ?>" method="post">
<table>
<tr><td>
<span class="gras">Auteur :</span>
</td><td>
<input type="text" name="auteur" maxlength="30" size="50" value="<?php if (isset($_POST['auteur'])) echo htmlentities(trim($_POST['auteur'])); ?>">
</td></tr><tr><td>
<span class="gras">Message :</span>
</td><td>
<textarea name="message" cols="50" rows="10"><?php if (isset($_POST['message'])) echo htmlentities(trim($_POST['message'])); ?></textarea>
</td></tr><tr><td><td align="right">
<input type="submit" name="go" value="Poster">
</td></tr></table>
</form>
<?php
if (isset($erreur)) echo '<br /><br />',$erreur;
?>
</body>
</html>