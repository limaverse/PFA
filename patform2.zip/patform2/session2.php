<?php 
include("inc\base.php");
session_start();
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];
$login= $_SESSION['user'];
?>
<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>compte</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("inc\entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="compte.php">compte</a></li>  
	<li><a href="discution.php">discution</a></li> 
	<?php  if($profile=='scolarite'){ ?>
  
	<li><a href="formation.php">formation</a></li> 

<?php }
if($profile!='admin'){
?>
 <li><a href="cour.php">cour</a></li> 
<li><a href="affichernote.php">note</a></li> 
    <li><a href="module.php">module</a></li> 
	<?php } ?>
	</ul>
	</div>
	<div id="corp">
	  


	  
	</div>
<div id="pied"></div>
	</body>
</html>