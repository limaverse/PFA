<?php 

include("div\base.php");
session_start();
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];
$res=mysqli_query($con,'select * from formation');
?>
<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>ajouter module</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="module.php">retour</a></li>  
	
	</ul>
	</div>
	<div id="corp">
	<form id="ajouter" method="post" >
			<fieldset>
				<legend>ajouter module</legend>
				
				<label for="nom">module: </label><input type="text" id="nom" name="nom"  /><br />
				<label for="prenom">duree : </label><input type="text" id="duree" name="duree" /><br />
				<label for="login">coef: </label><input type="text"id="coef" name="coef"  /><br />
                <select name="form" >
				<?php while($donne=mysqli_fetch_array($res,MYSQLI_BOTH)){ ?>
                <option value="<?php echo $donne['id']; ?>" ><?php echo $donne['nom_form']; ?></option>
                <?php } ?>
               </select>
			    <select name="prof" >
				<?php
                 $res1=mysqli_query($con,'select p.nom, p.id from professeur s , personnes p where s.id_personne=p.id');
				while($donne1=mysqli_fetch_array($res1,MYSQLI_BOTH)){ ?>
                <option value="<?php echo $donne1['id']; ?>" ><?php echo $donne1['nom']; ?></option>
                <?php } ?>
               </select>
              
			<input type="submit"   name="ajout" value="ajouter"/>				
			</fieldset>			
		</form>

<?php
if (!empty($_POST['nom']) )
$nom=$_POST['nom'];
if (!empty($_POST['form']) )
$form=$_POST['form'];
if(isset($_POST['ajout'])){
$resulta=mysqli_query($con,'select nom,id_form from module ');
while($donne=mysqli_fetch_array($resulta,MYSQLI_BOTH)){
$x=0;

if($donne['nom']==$nom){
if($donne['id_form']==$form){
$x=1;
BREAK;
}

}}
if($x==1){
echo 'compte existe deja';}
if($x==0){
$nom=$_POST['nom'];
$duree=$_POST['duree'];
$coef=$_POST['coef'];
$prof=$_POST['prof'];



$sql="insert into module(id_form,id_professeur,nom,duree,coef)values('$form','$prof','$nom','$duree','$coef')";

$res=mysqli_query($con,$sql);
echo 'module ajouté';
}}
?>
	</div>
<div id="pied"></div>
	</body>
</html>






