<?php 
try{
include("div\base.php");
session_start();
$nom= $_SESSION['nom'];


$login= $_SESSION['user'];
$reponce3=$con->prepare('SELECT m.nom,m.duree,m.coef from  module m ,etudiant e ,personnes p  where p.id=e.id_personne and e.id_formation=m.id_formation and  login=?');
$reponce3->execute(array( $login));

?>
<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>module</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">
	<ul>

	<li><a href="module.php">retour</a></li>  
	</ul>
	</div>
	<div id="corp">
	
	<table  border="2" id="tab1"><CAPTION>..formation..</CAPTION>
 	   <TH>module</TH> <TH>duree</TH>  <TH>coef</TH>
<?php 

while($tab=$reponce3->fetch()){ ?>

  <tr><td><?php echo $tab['nom'] ; ?></td><td><?php echo $tab['duree']?></td><td><?php echo $tab['coef']; ?></td></tr>
      
	  <?php  }?>
	  </table> 
	
	
	
	</div>
<div id="pied"></div>
	</body>
</html>
<?php }
catch(Exception $e){
echo 'Error:'.$e->getmessage();}?>