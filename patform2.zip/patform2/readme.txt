importer la base donne� 'platform' 

 
 
 
 
  administrateur   
 user:admin
 passe:admin
 
 
 
 
 scolarite    
 user:scolarite
 passe:scolarite
 
 
 professeur
 
 user : profeseur
 passe : professeur
 
 etudiant
 user :etudiant
 passe : etudiant