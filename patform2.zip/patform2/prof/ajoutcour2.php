<?php 

include("../inc/base.php");
session_start();
$nom= $_SESSION['nom'];





$mod=$_POST['mod'];


?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>compte</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">
	<ul>
	
	<li><a href="home.php">retour</a></li>  
	
	</ul>
	</div>
	<div id="corp">
	

			

	
<?php





$x=0;

if(isset($_FILES['avatar']))
{ 

     $dossier = '/patform2/cours/';
     $fichier = basename($_FILES['avatar']['name']);
     
$photo_dossier =$_SERVER['DOCUMENT_ROOT']."/patform2/cours/$fichier";
$res=mysqli_query($con,'select * from cours');
$nom=$_POST['nom'];
while($donne1=mysqli_fetch_array($res,MYSQLI_BOTH)){

if($donne1['id_module']==$mod && $donne1['nom']==$nom){


$x=1;
break;

}



}
if($x!=1){ 
$sql="insert into  cours (id_module,dossier,fichier,nom) values('$mod','$dossier','$fichier','$nom')";

$res1=mysqli_query($con,$sql);

if(move_uploaded_file($_FILES['avatar']['tmp_name'], $photo_dossier)) //Si la fonction renvoie TRUE, c'est que �a a fonctionn�...
     {
          echo 'Upload effectu� avec succ�s !'.$fichier;
  }
     else //Sinon (la fonction renvoie FALSE).
     {
          echo 'Echec de l\'upload !';
     }

}
else 
echo $donne1['nom'].'  existe d�ja';
}

?> 
</div>
<div id="pied"></div>
	</body>
</html>