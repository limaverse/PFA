<?php 

include("../inc/base.php");
session_start();
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];


if($profile=='professeur'){
$login= $_SESSION['user'];
$sql4="SELECT m.id,m.nom,f.nom_form from module m,personnes p,formation f WHERE m.id_professeur=p.id and f.id=m.id_form and p.login='$login'";
$res4=mysqli_query($con,$sql4);
?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>compte</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="cour.php">retour</a></li>  
	
	</ul>
	</div>
	<div id="corp">
	<form id="formation" method="post" >
<fieldset>
				<legend>choix des modules</legend>
				<select name="mod" >
				<?php while($donne1=mysqli_fetch_array($res4,MYSQLI_BOTH)){ ?>
                
               <option value="<?php echo $donne1['id']; ?>" ><?php echo $donne1['nom']; ?> *** <?php echo $donne1['nom_form']; ?></option>
               			   <?php } ?>
               </select>
  <input type="submit"   name="ajout" value="choisir"/>			   
			   </fieldset>			
		       </form>

<?php



if(isset($_POST['mod'])){
$mod=$_POST['mod'];
$sql5="select * from cours where id_module='$mod'";
$res5=mysqli_query($con,$sql5);
while($tab=mysqli_fetch_array($res5,MYSQLI_BOTH)){ ?>
	<table  border="2" id="tab1"><CAPTION>..formation..</CAPTION>
 	   <TH>cours</TH>
  <tr><td><a href="<?php echo $tab['dossier']?>/<?php echo $tab['fichier']?>"><?php echo $tab['nom']?></a></td></tr>
      
	  <?php } }?>
	  </table> 
	
	


</div>
<div id="pied"></div>
	</body>
</html>
<?php
	}
?>