<?php 

include("../inc/base.php");
session_start();
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];
$login= $_SESSION['user'];


$sql="SELECT m.id,m.nom,f.nom_form from module m,personnes p,formation f WHERE m.id_professeur=p.id and f.id=m.id_form and p.login='$login'";
$res=mysqli_query($con,$sql);
?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>compte</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="home.php">retour</a></li>  
	
	</ul>
	</div>
	<div id="corp">

				

			   <form  id="ajouter" method="POST" enctype="multipart/form-data" action="ajoutcour2.php">
			   <fieldset>
				<legend>choix des modules</legend>
			   <select name="mod" >
				<?php while($donne1=mysqli_fetch_array($res,MYSQLI_BOTH)){ ?>
                
              <option value="<?php echo $donne1['id']; ?>" ><?php echo $donne1['nom']; ?> *** <?php echo $donne1['nom_form']; ?></option>
               			   <?php } ?>
               </select>
			      </fieldset>
				  <fieldset>
				<legend>ajouter cour</legend>
cour : <input type="text" name="nom">
     <!-- On limite le fichier � 100Ko -->
     <input type="hidden" name="MAX_FILE_SIZE" value="100000">
	 <br/>
     Fichier : <input type="file" name="avatar">
     <input type="submit" name="envoyer" value="ajouter le fichier">
	 </fieldset>
</form>

	</div>
<div id="pied"></div>
	</body>
</html>