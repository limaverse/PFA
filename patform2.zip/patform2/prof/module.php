<?php 

session_start();
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];
?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>module</title>
	</head>
	
	<body>
	<div id='page'>
		<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">
	<ul>
	
	<li><a href="affichermodule.php">afficher module</a></li>	
    <li><a href="home.php">retour</a></li>  

	
	</ul>
	</div>
	<div id="corp">
	</div>
<div id="pied"></div>
	</body>
</html>