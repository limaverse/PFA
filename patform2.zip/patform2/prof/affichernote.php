<?php 

include("../inc/base.php");
session_start();
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];


if($profile=='scolarite'){
$res=mysqli_query($con,"select * from formation");
?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>notes</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="home.php">retour</a></li>  
	</ul>
	</div>
	<div id="corp">
	<table  border="2" id="tab1"><CAPTION>..formation..</CAPTION>
 	   <TH>formation</TH> <TH>duree</TH> 
<?php 
while($tab=mysqli_fetch_array($res,MYSQLI_BOTH)){ ?>
  <tr><td><?php echo $tab['nom_form']?></td><td><?php echo $tab['duree']?></td></tr>
       <?php } ?>
	  </table> 
	<form id="affi" method="post"  >
			<fieldset>
				<legend>choisissez une formation</legend>
                <select name="form" >
				<?php $res=mysqli_query($con,'select * from formation');
				while($tab=mysqli_fetch_array($res,MYSQLI_BOTH)){ ?>
                <option value="<?php echo $tab['id']; ?>" ><?php echo $tab['nom_form']; ?></option>
                <?php } ?>
               </select>
			<input type="submit"   name="aff" value="voir"/>				
			</fieldset>			
		</form>
<?php	
if(isset($_POST['form'])){
$form=$_POST['form'];
$sql="select * from module where id_form='$form'";
$res=mysqli_query($con,$sql);
?>
	<table  border="2" id="tab1"><CAPTION>..modules..</CAPTION>
 	   <TH>module</TH> <TH>duree</TH>  <TH>coef</TH>
<?php 
while($tab=mysqli_fetch_array($res,MYSQLI_BOTH)){ ?>
  <tr><td><?php echo $tab['nom']?></td><td><?php echo $tab['duree']?></td><td><?php echo $tab['coef']?></td></tr> 
	  <?php } ?>
	  </table> 
	  <form id="affi" method="post" action="affichernote2.php" >
			<fieldset>
				<legend>choisissez un module</legend>
                <select name="mod" >
				<?php 
				$res="select * from module where id_form='$form'";
				$res=mysqli_query($con,$sql);?>
				<?php 
				while($tab=mysqli_fetch_array($res,MYSQLI_BOTH)){ ?>
                <option value="<?php echo $tab['id']; ?>" ><?php echo $tab['nom']; ?></option>
                <?php } ?>
               </select>
			<input type="submit"   name="aff" value="voir"/>				
			</fieldset>			
		</form><?php } ?>
	</div>
<div id="pied"></div>
	</body>
</html>
<?php
}
if($profile=='etudiant'){
$login= $_SESSION['user'];
$sql1="SELECT m.id,m.nom,e.id_personne from  module m ,etudiant e ,personnes p  where p.id=e.id_personne and e.id_form=m.id_form and  login='$login'";
$res1=mysqli_query($con,$sql1);

?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>notes</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php echo "bonjour"." ".$nom;?> <a href="deconnexion.php">deconnexion</a></div>
	<div id="menu">
	<ul>

	<li><a href="home.php">retour</a></li>  
	</ul>
	</div>
	<div id="corp">
	<table  border="2" id="tab1"><CAPTION>..vos notes..</CAPTION>
 	   <TH>module</TH><TH>examen</TH><TH>ratrapage</TH>
<?php 
while($donne1=mysqli_fetch_array($res1,MYSQLI_BOTH)){
$module=$donne1['id'];
$id_etud=$donne1['id_personne'];
?>
<tr>
<?php
$sql2="select m.nom,n.examen,n.ratrapage from notes n , module m where m.id=n.id_module and n.id_module='$module' and n.id_etudiant='$id_etud'";
$res2=mysqli_query($con,$sql2);

while($tab=mysqli_fetch_array($res2,MYSQLI_BOTH)){ ?>
<td><?php echo $tab['nom'] ;?></td><td><?php echo $tab['examen'] ;?></td><td><?php echo $tab['ratrapage'] ;?></td></tr>
      
	  <?php } ?>
	  </table> 

</div>
<div id="pied"></div>
	</body>
</html>
<?php
}
}
if($profile=='professeur'){
$login= $_SESSION['user'];
$sql3="SELECT m.id,m.nom,f.nom_form from module m,personnes p,formation f WHERE m.id_professeur=p.id and f.id=m.id_form and p.login='$login'";
$res3=mysqli_query($con,$sql3);
?>
<html>
	<head><link href="../css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>compte</title>
	</head>
	
	<body>
	<div id='page'>
	<div id='entete'><?php include("../inc/entete.php"); ?></div>
	<div id="menu">
	<ul>
	<li><a href="home.php">retour</a></li>  
	
	</ul>
	</div>
	<div id="corp">
	<form id="formation" method="post" >
<fieldset>
				<legend>choix des modules</legend>
				<select name="mod" >
				<?php while($donne1=mysqli_fetch_array($res3,MYSQLI_BOTH)){ ?>
                
               <option value="<?php echo $donne1['id']; ?>" ><?php echo $donne1['nom']; ?> *** <?php echo $donne1['nom_form']; ?></option>
               			   <?php } ?>
               </select>
  <input type="submit"   name="ajout" value="choisir"/>			   
			   </fieldset>			
		       </form>

<?php



if(isset($_POST['mod'])){
$module=$_POST['mod'];
$sql4="SELECT p.nom, p.prenom, n.examen,n.ratrapage FROM module m, etudiant e, personnes p, notes n WHERE p.id = e.id_personne AND e.id_form = m.id_form AND m.id = n.id_module AND m.id ='$module'";
$res4=mysqli_query($con,$sql4);
?>

	<table  border="2" id="tab1"><CAPTION>..formation..</CAPTION>
 	   <TH>nom</TH><TH>prenom</TH><TH>examen</TH><TH>ratrapage</TH>
<?php 

while($tab=mysqli_fetch_array($res4,MYSQLI_BOTH)){ ?>

  <tr><td><?php echo $tab['nom']?></td><td><?php echo $tab['prenom']?></td><td><?php echo $tab['examen']?></td><td><?php echo $tab['ratrapage']?></td></tr>
      
	  <?php } ?>
	  </table> 
	
	


</div>
<div id="pied"></div>
	</body>
</html>
<?php



}}

	
?>