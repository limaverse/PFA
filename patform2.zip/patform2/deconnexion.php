<?php

session_start();// d�marrer une session
$typ = $_SESSION['type'];
header('Location:index.php'); 
SESSION_unset();
SESSION_destory();
?>