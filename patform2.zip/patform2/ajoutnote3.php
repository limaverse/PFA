<?php 
try{
include("div\base.php");

session_start();

$module=$_SESSION['module1'];

$id_etud=$_SESSION['etud'];

$nom= $_SESSION['nom'];

$profile= $_SESSION['profile'];




unset($_SESSION['etud']);
$note=$_POST['note'];
$obs=$_POST['obs'];


?>
<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>notes</title>
	</head>
	
	<body>
	<div id='page'>
<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">
	</div>
	<div id="corp">
	<?php  
if($obs=='exm'){
$reponce2=$bdd->prepare('insert into notes (id_module,id_etudiant,examen) values (?,?,?) ');

$reponce2->execute(array($module,$id_etud,$note));}	
else if($obs=='rat'){
$reponce2=$bdd->prepare('UPDATE notes SET ratrapage=?  WHERE id_module=? and id_etudiant=?');

$reponce2->execute(array($note,$module,$id_etud));}
?>
	<li><a href="ajoutnote.php">ajouter une autre note</a></li> 
	<li><a href="session2.php">accueil</a></li> 
	</div>
<div id="pied"></div>
	</body>
</html>
<?php
}

	
catch(Exception $e){
echo 'Error:'.$e->getmessage();}?>