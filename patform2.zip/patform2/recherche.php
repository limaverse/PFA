<?php 
try{
include("div\base.php");
session_start();// d�marrer une session

$profile= $_SESSION['profile'];
$nom= $_SESSION['nom'];
if ($profile=='admin'){




?>

<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>modification des comptes</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">	<ul > 

	<li><a href="compte.php">compte</a></li> 
	<li><a href="session2.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
	
		
	
<?php	
		  $reponce=$bdd->query("select * from personnes ");
		     
            ?>
<table  border="2" id="tab1"><CAPTION>..table utilisateurs..</CAPTION>
 	   <TH>NOM</TH> <TH>PRENOM</TH> <TH>LOGIN</TH> <TH>profile</TH> <TH>adresse</TH> <TH>email</TH><TH>tel</TH> 
<?php while($tab=$reponce->fetch()){ ?>

  <tr ><td> <?php echo $tab['nom']?></td><td><?php echo $tab['prenom']?></td><td><?php echo $tab['login']?></td><td><?php echo $tab['profile']?></td><td><?php echo $tab['adresse']?></td>
  <td><?php echo $tab['email']?></td>  <td><?php echo $tab['tel']?></td></tr>
      
	  <?php } ?>
	  
	  </table> 
         
		</div>
<div id="pied"></div>	
	</div>
	</body>
</html>
<?php
}

else if ($profile=='scolarite'){




?>

<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>rechercher des comptes</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">	<ul > 

	<li><a href="compte.php">compte</a></li> 
	<li><a href="session2.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
		 <form id="recherche" method="post">
			<fieldset>
				<legend>rechercher</legend>
				<label for="nom">user: </label><input type="text" id="login" name="login" /><br />
				<input type="submit"  id="rech" name="rech" value="rechercher"/>				
			</fieldset>			
		</form>
		
	
<?php	if(isset($_POST['rech'])){
	      $user=$_POST['login'];
		  $reponce=$bdd->prepare("select * from personnes where (login=? )");
		     $reponce->execute(array ($_POST['login'])); 
            while($donne=$reponce->fetch()){?>



   
         <form id="aff"  >
			<fieldset>
				<legend>resultat</legend>
				<label for="nom">nom: </label><input type="text" readonly="readonly"id="nom" name="nom" value="<?php echo $donne['nom'] ?>" /><br />
				<label for="prenom">prenom : </label><input type="text" readonly="readonly"id="prenom" name="prenom" value="<?php echo $donne['prenom'] ?>" /><br />
				<label for="login">user: </label><input type="text" readonly="readonly" id="user" name="user"  value="<?php echo $donne['login'] ?>" /><br />
				<label for="telephone">telephone: </label><input type="text"readonly="readonly" id="telephone" name="telephone" value="<?php echo $donne['tel'] ?>" /><br />
				<label for="adresse">adresse: </label><input type="text"readonly="readonly" id="adresse" name="adresse" value="<?php echo $donne['adresse'] ?>" /><br />
				<label for="email">email: </label><input type="email"readonly="readonly" id="email" name="email" value="<?php echo $donne['email'] ?>" /><br />
				<label for="profile">profile: </label><input type="profile"readonly="readonly" id="profile" name="profile" value="<?php echo $donne['profile'] ?>" /><br />
     	
			</fieldset>			
		</form>
		</div>
<div id="pied"></div>	
	</div>
	</body>
</html>
<?php
}}}}
catch(Exception $e){
echo 'Error:'.$e->getmessage();}?>