<?php 
try{
include("div\base.php"); 
session_start();
$nom= $_SESSION['nom'];
$profile= $_SESSION['profile'];
if($profile=='scolarite'){
?> 
<html>
	<head><link href="css/cssmodifier.css" rel="stylesheet" type="text/css" title="TITRE" />
<title>modifier formation</title>
	</head>
	<body>
	<div id='page'>
	<div id='entete'><?php include("div\entete.php"); ?></div>
	<div id="menu">	<ul > 
	<li><a href="formation.php">formation</a></li> 
	<li><a href="session2.php">accueil</a></li> 
	</ul ></div>
	<div id="corp">
		<form id="modifier" method="post" >
			<fieldset>
				<legend>modifier</legend>
				<label for="nom">nom de la formation: </label><input type="text" id="nom" name="nom"  /><br />
				<label for="nom1">modifier le nom: </label><input type="text" id="nom1" name="nom1"  /><br />
				<label for="duree">modifier la duree de la formation: </label><input type="text" id="duree" name="duree"  /><br />
			<input type="submit"   name="mod" value="modifier"/>				
			</fieldset>			
		</form>
<?php
$x=0;

if(isset($_POST['mod'])){
$nom=$_POST['nom'];
$nom1=$_POST['nom1'];

$duree=$_POST['duree'];

$reponce1=$bdd->prepare('select * from formation where nom_form=?');
$reponce1->execute(array($nom));
while($donne1=$reponce1->fetch()){
if($donne1['nom']==$nom){
$x=1;
break;
}

}
if($x==1 && $nom!=$nom1){
$reponce2=$bdd->prepare('UPDATE formation SET nom_form=? ,duree=?  WHERE nom_form=? ');
$reponce2->execute(array($nom1,$duree,$nom));
echo 'formation'.$nom.'modifier avec succes  ' ;}
else if($nom!=$nom1) {
echo 'erreur modification';
}

if( $x==1 && $nom==$nom1){
$reponce2=$bdd->prepare('UPDATE formation SET duree=?  WHERE nom_form=? ');
$reponce2->execute(array($duree,$nom));
echo 'duree formation'.$nom .'modifier avec succes  ' ;}

}
}
}

catch(Exception $e){
echo 'Error:'.$e->getmessage();}
?>